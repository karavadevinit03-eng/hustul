# Bambai Hustle: guide for AI coding agents

This file is the shared brief for every AI that works on this project (Claude, ChatGPT / Codex, or anything else).
Read it fully before changing code. Then read the latest entries in `CHANGELOG.md`, because another AI may have
changed things since you last looked.

## What this is

Bambai Hustle is a GTA-style open-world game that runs in the browser, set in Mumbai with Indian culture.
The owner is Vinit, who builds it for himself, for free. Vinit gives the direction and the AI agents do the work.

- One page: `index.html` holds all the HTML, CSS and JavaScript (about 5,600 lines, about 490 KB).
- Engine: three.js **r128**, loaded from cdnjs, plus the r128 post-processing scripts from jsdelivr
  (EffectComposer, RenderPass, ShaderPass, UnrealBloomPass). Do not upgrade three.js casually: r128 globals
  (`THREE.*`) and the `examples/js` scripts are used everywhere, and newer versions removed them.
- No build step, no npm, no framework. Open the file and it runs.
- Progress saves in the browser's localStorage (`bambai-hustle-save-v1`). Graphics quality is stored under its own key.

## How to run it

- Double-click `index.html`, or
- run `python3 -m http.server 8000` in this folder and open http://localhost:8000

It needs internet access the first time, for three.js and Google Fonts.

## Where things are in index.html

All game code is in one IIFE near the end of the file. Big sections start with banner comments like
`/* ============================================================ vehicles`. Search for these rather than trusting
line numbers, because line numbers move with every edit.

| Banner to search for | What lives there |
|---|---|
| `helpers` | `lerp`, `clamp`, `smooth`, `TAU` and other small maths helpers |
| `map data` | the road graph (`NODES`, `EDGES`), real Mumbai road names, districts, `LANDMARKS` |
| `geometry queries` / `collision boxes` | `walkable`, `roadDist`, the spatial grid for building collisions |
| `three.js setup` | renderer, scene, sea shader, bloom and colour-grade post-processing |
| `merge helpers` | `merge()` packs many primitives into one vertex-coloured geometry, to keep draw calls low |
| `landmarks` / `buildings` | Gateway of India, CSMT, Haji Ali, Sea Link and the rest; facade textures, shopfronts, hoardings |
| `vehicles` | `VSPEC` (every vehicle's handling and label), plates, suspension, wheels |
| `smooth surfaces` | `track`, `grid`, `sec`, `tube`: the lofting toolkit used for cars, bikes and animals |
| `lofted car bodies` | `CAR_DEFS` and `carParts()` for taxi, car, police, sport, super, gt, hyper |
| `perfParts` / `vehicleParts` | bikes, scooter and boat (perfParts); auto-rickshaw and bus (vehicleParts), all lofted with the smooth-surface toolkit |
| `characters` / `bodyParts` | the character mesh: head, face, hair, torso, arms, legs, feet, `OUTFITS` |
| `poses` | locomotion, leg and arm IK, bike riding, climbing, stumbles, idle acts |
| `ragdoll physics` | ragdolls for the player and pedestrians |
| `harbour`, `stunt jumps`, `Focus` | speedboat jetty, six stunt ramps, slow-motion meter |
| `state` / `audio` / `UI helpers` | `ST` (saved game state), `save()`, `loadSave()`, sounds, toasts |
| `missions` | `MISSIONS`, taxi fares, races |
| `heat and police` / `wanted level` / `police on foot` / `police helicopter` | the wanted system |
| `input` | keyboard, mouse, touch controls |
| `vehicles: enter, exit, drive` | getting in and out, driving model, ramps, dents, exhaust |
| `combat` | `WEAPONS`, weapon wheel, hitscan, particles, health and armour, melee, shooting, pickups, hospitals |
| `vehicle damage` | smoke, fire, explosions, burnt shells |
| `GPS` | routing along the road graph |
| `GTA-style street life` | phone, radio (`RSTATIONS`), Bambai Customs mod shop, traffic signals, Nukkad 24x7 stores, random street events, stray dogs and cows (`animalGeo`) |
| `updates` | per-frame updates for player, traffic, pedestrians, secondary motion |
| `time and weather` | day and night, rain, car reflection cube map |
| `camera` | on-foot orbit, chase cams, first person, hood, cinematic |
| `HUD and maps` | radar, full map with zoom and pan |
| `loop` / `boot` | `stepWorld`, `frame`, adaptive resolution, start menu, `window.__bh` debug hooks |

### Vehicle types (keys of `VSPEC`)

`taxi`, `auto`, `car`, `bus`, `police`, `sport`, `super`, `gt`, `hyper`, `sbike`, `tbike`, `classic`, `scooter`, `boat`.
Display names such as "Lancetti Furia" or "Kazeyama ZR-10" are invented on purpose.

### Debug hooks

`window.__bh` exposes internals for testing, for example `__bh.begin(true)` (new game), `__bh.sim(frames, dt)`
(step the game), `__bh.player`, `__bh.ST`, `__bh.drawStats()` (draw calls and triangles), `__bh.cam3(...)`
(a debug camera). Keep these working, because the tests use them. If you add a big system, expose it here too.

## Rules (please follow all of these)

### Content
1. **No real brands.** No real car, bike, shop, radio, drink or company names and no copied logos or designs.
   Invent names (the existing ones are Lancetti, Vellucci, Solaire, Kessler, Kazeyama, Shakti, Sawari, Nukkad 24x7).
   Radio frequencies were picked so they don't match real Mumbai stations.
2. **No Rockstar or GTA assets, names, music or logos.** "GTA-style" means the feel, not copied content.
3. **No blood or gore.**
4. **Weapons stay holstered at places of worship** (Haji Ali, Siddhivinayak and so on). Keep that check working.
5. Real Mumbai landmark and road names are fine. Keep Indian details right: right-hand-drive cars, white private
   plates and yellow commercial plates (all numbers made up), kaali-peeli taxis, khaki Mumbai Police uniforms.
6. Player-facing text: plain, friendly English (Hindi or Marathi flavour is welcome). **Never use em dashes.**

### Code
1. **Keep it one self-contained `index.html`.** External scripts only from cdnjs.cloudflare.com, cdn.jsdelivr.net,
   or unpkg.com, with exact versions. No new frameworks or build tools.
2. **Small, focused edits.** Never reformat, re-indent or reorder the whole file. Huge diffs make it impossible for
   the other AI to merge its work, and impossible for Vinit to see what changed.
3. **Stay inside the performance budget.** Today the busiest views (around CSMT and Fort, on High) use about 430
   draw calls and 1.4 million triangles. Don't let new work push those numbers up much. Merge static parts with `merge()`, share geometries and materials, and use the
   low-poly helpers (such as `G.sphL`) for small details. Check with `__bh.drawStats()`.
4. **Don't break saves.** If you add fields to `ST`, default them when loading old saves, as `boot` already does.
5. The page must work both inside Claude's artifact viewer and on its own. The photo download already falls back
   to a plain link when `window.claude` isn't there. Keep that fallback pattern for anything similar.
6. No console errors. Test on both Graphics: High and Graphics: Low.

## Testing

- Run the smoke test: `pip install playwright && python -m playwright install chromium`, then
  `python tests/smoke_test.py`. It opens the game in a headless browser, starts a new game, drives the simulation
  for a while, prints any errors and saves `tests/smoke.png`. It must end with `PASS`.
- Then play it for a minute: walk, get in a car (E), drive, change camera (V), open the map (M), fire a weapon,
  get a wanted star and lose it.
- Say honestly what you tested and what you did not.

## Working together (Claude and ChatGPT on one project)

- **GitHub is the single source of truth.** Always start from the latest `main`. Never start from an old copy
  of `index.html` from a chat or a download folder.
- **One task, one branch, one pull request.** Name branches like `claude/remodel-auto` or `codex/new-mission`.
  Vinit reviews and merges. Don't push straight to `main` unless Vinit asks.
- **Don't let both AIs edit the same section at the same time.** If two tasks touch the same area, finish and
  merge one before starting the other.
- **Leave a handoff note.** When you finish, add an entry at the top of the "Handoff log" in `CHANGELOG.md`:
  date, who you are (Claude or ChatGPT/Codex), what changed, what you tested, and anything left half-done.
- **Read the handoff log before you start**, so you don't redo or undo the other AI's work.
