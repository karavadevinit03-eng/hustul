"""Smoke test for Bambai Hustle.

Opens index.html in headless Chromium, starts a new game, runs the simulation for a while, gets into a car,
and checks there were no JavaScript errors. Saves a screenshot to tests/smoke.png.

Setup:  pip install playwright && python -m playwright install chromium
Run:    python tests/smoke_test.py

Offline use (no access to the CDNs): unpack the three@0.128.0 npm package somewhere and set THREE_DIR to it,
for example THREE_DIR=/path/to/package python tests/smoke_test.py
"""
import functools, http.server, os, sys, threading
from playwright.sync_api import sync_playwright

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
THREE_DIR = os.environ.get('THREE_DIR')


def serve():
    class Quiet(http.server.SimpleHTTPRequestHandler):
        def log_message(self, *a):
            pass
    handler = functools.partial(Quiet, directory=ROOT)
    srv = http.server.ThreadingHTTPServer(('127.0.0.1', 0), handler)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    return srv


def main():
    srv = serve()
    url = 'http://127.0.0.1:%d/index.html' % srv.server_address[1]
    errors = []
    with sync_playwright() as p:
        browser = p.chromium.launch(args=['--use-gl=angle', '--use-angle=swiftshader',
                                          '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'])
        page = browser.new_page(viewport={'width': 1280, 'height': 720})
        page.on('pageerror', lambda e: errors.append('page error: %s' % e))
        # a font that fails to download is harmless; anything else logged as an error counts
        page.on('console', lambda m: errors.append('console error: %s' % m.text)
                if m.type == 'error' and 'Failed to load resource' not in m.text else None)
        if THREE_DIR:
            def route(r):
                u = r.request.url
                if 'three.min.js' in u:
                    return r.fulfill(path=os.path.join(THREE_DIR, 'build/three.min.js'), content_type='application/javascript')
                if 'three@0.128.0/' in u:
                    return r.fulfill(path=os.path.join(THREE_DIR, u.split('three@0.128.0/')[1]), content_type='application/javascript')
                if u.startswith('http://127.0.0.1'):
                    return r.continue_()
                return r.abort()
            page.route('**/*', route)
        page.goto(url, wait_until='domcontentloaded', timeout=120000)
        page.wait_for_function('!!(window.__bh && window.__bh.begin)', polling=500, timeout=180000)
        page.evaluate('window.__bh.begin(true)')
        page.evaluate('window.__bh.sim(240, 1/60)')
        stats = page.evaluate('window.__bh.drawStats()')
        # walk up to the nearest parked or passing car and get in
        got_in = page.evaluate('''() => {
            const B = window.__bh, P = B.player;
            const cars = B.allVehicles().filter(v => !v.dead && v.type !== 'boat');
            cars.sort((a, b) => Math.hypot(a.x - P.x, a.z - P.z) - Math.hypot(b.x - P.x, b.z - P.z));
            if (!cars.length) return false;
            P.x = cars[0].x + 2; P.z = cars[0].z;
            B.tryEnter(); B.sim(240, 1/60);
            return !!P.veh;
        }''')
        page.evaluate('window.__bh.sim(120, 1/60)')
        page.screenshot(path=os.path.join(ROOT, 'tests', 'smoke.png'), timeout=240000)  # software rendering can be slow
        browser.close()
    srv.shutdown()
    print('draw calls: %s, triangles: %s, got into a vehicle: %s' % (stats['calls'], stats['tris'], got_in))
    if errors:
        print('FAIL')
        for e in errors[:20]:
            print('  ' + e)
        sys.exit(1)
    print('PASS')


if __name__ == '__main__':
    main()
