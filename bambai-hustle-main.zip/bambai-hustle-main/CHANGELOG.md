# Changelog

## Handoff log

Newest first. Every AI adds an entry here when it finishes a task.
Format: date, who (Claude or ChatGPT/Codex), what changed, what was tested, what is left.

### 2026-10-25, Claude: smooth auto-rickshaw and double-decker bus
- Auto-rickshaw rebuilt from lofted surfaces: a rounded front shield with a chrome-ringed headlamp and indicators,
  a two-tone yellow and green rear tub, a curved black canopy with side flaps, padded seats, a front mudguard,
  a rear bumper and a little nimbu-mirchi charm hanging at the front.
- Double-decker bus rebuilt as one smooth shell with a domed roof and rounded corners, skirts between proper
  wheel arches, tinted glazing with pillars on both decks, a cream band, a kerb-side door, a lit destination board,
  round headlamps, mirrors and bumpers. Bus roof height for climbing updated to match.
- Tested: `tests/smoke_test.py` passes; missions, race, police and traffic test passes with no errors.
  Draw calls and triangles rose slightly (about 440 draw calls and 1.41 million triangles at the start view).
- Left: the local train is still a good next job.

### 2026-10-25, Claude: packaged for GitHub
- Packaged the project for GitHub: `index.html` (the game as a standalone page), `AGENTS.md` (shared guide),
  `CLAUDE.md` (points Claude at the same guide), this changelog, `README.md` and `tests/smoke_test.py`.
- Tested: `tests/smoke_test.py` passes. The standalone `index.html` loads, starts a new game, gets into a taxi
  and runs the simulation with no errors.
- Suggested next jobs: remodel the auto-rickshaw and the double-decker bus with the smooth-surface toolkit
  (`tube`, `grid`, `sec`) like the cars; add the local train.

## Version history

### v7: smoother models
Lofted, curved car bodies for all seven car types, with wheel arches, glass that follows the roof line and
surface-mounted mirrors, seams, lamps, grilles and plates. Flowing bike fairings and teardrop tanks. A humped
Indian cow and a sturdier street dog. A refined face, fingers on the player's hands, and fixes for the kurta
side seam and the selfie arm.

### v6: GTA vibe pack
Smoother vehicles and finishing, character physics and textures, plus: phone (contacts, camera, selfies, texts),
five radio stations, the Bambai Customs mod shop, traffic signals, Nukkad 24x7 stores you can buy from or rob,
random street events, stray dogs and cows, six stunt ramps, a speedboat at the Gateway jetty, and the Focus
slow-motion meter.

### v5: performance vehicles, cameras and map
Superbikes and supercars with invented makes, more camera modes (close, far, first person, hood, cinematic),
a zoomable and draggable full map, and real Mumbai road names on the street graph.

### v4: character movement
Smoother locomotion with planted feet, IK, idle acts and better character looks.

### v3: GTA references
Combat, weapons and the weapon wheel, health and armour, a wanted level with police on foot and a helicopter,
pickups, hospitals and police chowkis.

### v2: realism pass
A more realistic character, ragdoll physics and better graphics.

### v1: first build
Mumbai's top locations from Colaba to Bandra, taxis, traffic, pedestrians, missions and taxi fares.
