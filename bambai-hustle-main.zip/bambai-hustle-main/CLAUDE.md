@AGENTS.md

Claude: the shared project guide is AGENTS.md (imported above). ChatGPT / Codex reads the same file, so keep
project rules there rather than here. Before starting, read the latest entries in CHANGELOG.md.
