# Bambai Hustle

A GTA-style open-world game set in Mumbai that runs in the browser. You step off the train at CSMT with nothing
but a phone number, drive kaali-peeli taxis from Colaba to Bandra, run jobs and make the city yours.

A fictional story set among real Mumbai landmarks. All vehicle makes, shops and brands are made up.

## Play

Double-click `index.html`, or run `python3 -m http.server 8000` here and open http://localhost:8000.
It needs internet access for three.js and fonts. Progress saves in your browser.

**Controls:** WASD move or drive, mouse looks (click the game first), right click aims, left click shoots or
punches, Tab weapon wheel, Shift sprint, Space jump or handbrake, E get in or out, V camera, M map, T taxi
fares, R radio, U phone, B Focus, P pause.

## Files

| File | What it is |
|---|---|
| `index.html` | the whole game |
| `AGENTS.md` | the shared guide that Claude and ChatGPT/Codex both read before changing anything |
| `CLAUDE.md` | tells Claude to use AGENTS.md |
| `CHANGELOG.md` | version history plus the handoff log, where each AI notes what it changed |
| `tests/smoke_test.py` | quick automated check that the game starts and runs without errors |

## Working with Claude and ChatGPT

1. Keep this folder in one GitHub repository. That repo is the only "real" copy.
2. Give one task at a time to one AI. Each one works on its own branch and opens a pull request.
3. You review and merge. Then the other AI starts from the updated code.
4. Each AI writes a short note in `CHANGELOG.md` so the other one knows what happened.
